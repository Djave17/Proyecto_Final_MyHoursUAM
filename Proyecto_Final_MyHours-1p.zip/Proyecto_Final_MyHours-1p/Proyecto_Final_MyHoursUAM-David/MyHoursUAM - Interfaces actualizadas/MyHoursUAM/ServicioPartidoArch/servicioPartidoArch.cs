﻿using MyHours_UAMApp.Estructuras;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyHours_UAMApp.ServicioPartidoArch
{
   internal class PartidoArchivoServicio
   {
     


      
     
   }
}
