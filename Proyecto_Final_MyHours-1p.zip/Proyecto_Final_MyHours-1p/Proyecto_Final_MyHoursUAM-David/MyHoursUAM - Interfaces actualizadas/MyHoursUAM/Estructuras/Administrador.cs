﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyHours_UAMApp.Estructuras
{
    internal class Administrador
    {
        public string cifAdministrador { get; set; }
        public string contraseñaAdministrador { get; set; }
    }
}
