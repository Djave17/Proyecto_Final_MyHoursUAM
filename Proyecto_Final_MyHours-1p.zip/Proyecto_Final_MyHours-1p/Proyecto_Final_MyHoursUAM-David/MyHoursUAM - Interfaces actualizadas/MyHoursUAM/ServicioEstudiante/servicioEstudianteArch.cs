﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyHours_UAMApp.Estructuras;

namespace MyHours_UAMApp.ServicioEstudiante
{
   internal class EstudianteArchivoServicio
   {
   }   


      }

