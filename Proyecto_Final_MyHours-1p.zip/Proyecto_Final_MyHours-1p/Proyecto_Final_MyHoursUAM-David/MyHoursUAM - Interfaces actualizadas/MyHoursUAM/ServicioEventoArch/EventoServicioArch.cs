﻿using MyHours_UAMApp.Estructuras;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static MyHours_UAMApp.Estructuras.Evento;

namespace MyHours_UAMApp.ServicioEventoArch
{
   internal class EventoArchivoServicio
   {




   }
}
