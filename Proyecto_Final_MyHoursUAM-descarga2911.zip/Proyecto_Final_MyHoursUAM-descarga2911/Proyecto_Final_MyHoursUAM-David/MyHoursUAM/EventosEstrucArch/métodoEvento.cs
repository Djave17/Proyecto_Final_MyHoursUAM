﻿using MyHours_UAMApp.Estructuras;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static MyHours_UAMApp.Estructuras.Evento;


namespace MyHours_UAMApp.EventosEstrucArch
{
   public  class métodoEvento
   {
      public void GuardarEventos(List<Evento> eventos, string rutaArchivo1)
      {
         using (FileStream archivo = new FileStream(rutaArchivo1, FileMode.Create, FileAccess.Write))
         {
            using (BinaryWriter escritor = new BinaryWriter(archivo))
            {
               foreach (Evento c in eventos)
               {
                  escritor.Write(c.nombreEvento.Length);
                  escritor.Write(c.nombreEvento.ToCharArray());
                  escritor.Write(c.fechaEvento.Length);
                  escritor.Write(c.fechaEvento.ToCharArray());
                  escritor.Write(c.horaEvento.Length);
                  escritor.Write(c.horaEvento.ToCharArray());
                  escritor.Write(c.descripcionEvento.Length);
                  escritor.Write(c.descripcionEvento.ToCharArray());
                  escritor.Write(c.cantidadConvalidar);
                  escritor.Write(c.organizadorEvento.Length);
                  escritor.Write(c.organizadorEvento.ToCharArray());
                  escritor.Write(c.lugarEvento.Length);
                  escritor.Write(c.lugarEvento.ToCharArray());
                  escritor.Write(c.idEvento.Length);
                  escritor.Write(c.idEvento.ToCharArray());
                  escritor.Write(c.cupos);
                  escritor.Write((int)c.estadoEvento); // Guardar EstadoEvento como entero
                  escritor.Write((int)c.tipoEvento);   // Guardar TipoEvento como entero
               }
            }
         }
      }

      public List<Evento> CargarEventos(string rutaArchivo1)
      {
         List<Evento> eventos = new List<Evento>();

         // Verificar si el archivo existe
         if (!File.Exists(rutaArchivo1))
         {
            return eventos;
         }

         using (FileStream archivo = new FileStream(rutaArchivo1, FileMode.Open, FileAccess.Read))
         {
            using (BinaryReader lector = new BinaryReader(archivo))
            {
               // Leer mientras no lleguemos al final del archivo
               while (archivo.Position != archivo.Length)
               {
                  // Leer las propiedades del evento en el mismo orden en que se guardaron
                  int tamañoNombre = lector.ReadInt32();
                  char[] nombreArray = lector.ReadChars(tamañoNombre);
                  string nombreEvento = new string(nombreArray);

                  int tamañoFecha = lector.ReadInt32();
                  char[] fechaArray = lector.ReadChars(tamañoFecha);
                  string fechaEvento = new string(fechaArray);

                  int tamañoHora = lector.ReadInt32();
                  char[] horaArray = lector.ReadChars(tamañoHora);
                  string horaEvento = new string(horaArray);

                  int tamañoDescripcion = lector.ReadInt32();
                  char[] descripcionArray = lector.ReadChars(tamañoDescripcion);
                  string descripcionEvento = new string(descripcionArray);

                  int cantidadConvalidar = lector.ReadInt32();

                  int tamañoOrganizador = lector.ReadInt32();
                  char[] organizadorArray = lector.ReadChars(tamañoOrganizador);
                  string organizadorEvento = new string(organizadorArray);

                  int tamañoLugar = lector.ReadInt32();
                  char[] lugarArray = lector.ReadChars(tamañoLugar);
                  string lugarEvento = new string(lugarArray);

                  int tamañoId = lector.ReadInt32();
                  char[] idArray = lector.ReadChars(tamañoId);
                  string idEvento = new string(idArray);

                  int cupos = lector.ReadInt32();

                  // Leer los valores enteros de los enums y convertirlos
                  EstadoEvento estado = (EstadoEvento)lector.ReadInt32();
                  TipoEvento tipo = (TipoEvento)lector.ReadInt32();

                  // Crear la instancia del evento y añadirla a la lista
                  Evento evento = new Evento
                  {
                     nombreEvento = nombreEvento,
                     fechaEvento = fechaEvento,
                     horaEvento = horaEvento,
                     descripcionEvento = descripcionEvento,
                     cantidadConvalidar = cantidadConvalidar,
                     organizadorEvento = organizadorEvento,
                     lugarEvento = lugarEvento,
                     idEvento = idEvento,
                     cupos = cupos,
                     estadoEvento = estado,
                     tipoEvento = tipo
                  };

                  eventos.Add(evento);


               }
            }
         }

         return eventos;
      }

   }
}
