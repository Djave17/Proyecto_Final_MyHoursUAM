﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyHours_UAMApp.Estructuras
{
   [Serializable]
   internal class Partido : Evento
   {
      /// <summary>
      /// Representa un partido deportivo que hereda de la clase evento
      /// </summary>
      public string nombrePartido { get; set; }
      public string lugarPartido { get; set; }
      public string rival { get; set; }
      public enum TipoDeporte // define el tipo de deporte que se realizara en el partido como un enum
      {
         futbol,
         baloncesto,
         voleibol,
         tenis,
         VoleibolPlaya,
         futbolSala,
         karate,
         taekwondo,
         ajedrez,
         natacion,
         atletismo,
      }
      public TipoDeporte deporte { get; set; }
   }
}
