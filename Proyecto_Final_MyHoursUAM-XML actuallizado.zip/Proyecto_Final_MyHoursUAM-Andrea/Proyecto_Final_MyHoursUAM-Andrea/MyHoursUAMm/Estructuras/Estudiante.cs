﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyHours_UAMApp.Estructuras
{
   [Serializable]
   internal class Estudiante
   {
      /// <summary>
      /// Clase de estudiante
      /// </summary>
      public string nombreEstudiante { get; set; }

      public string apellidoEstudiante { get; set; }
      public int HorasCompletadas { get; set; }

      public string correoEstudiante { get; set; }
      public string cifEstudiante { get; set; }
      public string contraseñaEstudiante { get; set; }


      public List<string> eventosAsistidos { get; set; } // IDs de eventos asistidos
      public List<string> partidosAsistidos { get; set; } // IDs de partidos asistidos
      public Asistencia asistencia { get; set; }

      // Constructor
      public Estudiante()
      {
         eventosAsistidos = new List<string>(); //// Inicializa la lista que contiene los identificadores de eventos asistidos por el estudiante.
         asistencia = new Asistencia(); // Inicializa la instancia de la clase Asistencia para registrar detalles de asistencia.
      }

      // Método para registrar asistencia y contar las horas y partidos realizados

   }

}

