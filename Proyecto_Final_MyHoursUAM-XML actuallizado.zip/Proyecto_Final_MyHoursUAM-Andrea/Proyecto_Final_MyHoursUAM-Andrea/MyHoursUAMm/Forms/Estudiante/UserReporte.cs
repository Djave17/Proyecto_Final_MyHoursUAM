﻿using MyHours_UAMApp.Estructuras;
using MyHours_UAMApp.Estructuras.Metodos;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace MyHours_UAMApp
{
   public partial class UserReporte : Form
   {
      public UserReporte()
      {
         InitializeComponent();
         if (!ValidarSesion())
         {
            return; // Si no hay sesión, se detiene el flujo de inicialización.
         }
         else
         {
            var (eventos, partidos) = ObtenerDatosAsistidos();  // Obtener datos relacionados con eventos y partidos asistidos.
            CargarDatosEnListViews(eventos, partidos);
            ActualizarEstadisticas();
         }

      }


      private void UserReporte_Load(object sender, EventArgs e)
      {

         /// <summary>
         ///  Obtener los partidos asistidos por el estudiante actual y cargarlos en el ListView.
         /// </summary>
         // sintaxis: var + nombre + = +  nombre carpeta. nombre funcion + clase herencia + variables necesarias 
         var partidosAsistidos = Metodos.ObtenerPartidosAsistidos(SesionActual.EstudianteActual.cifEstudiante);
         Metodos.CargarPartidosAsistidos(lvwPartidosAsistidos, partidosAsistidos);

      }
      private bool ValidarSesion()
      {
         // sintaxis: var + nombre + = + nombre carpeta o clase . variable
         var estudiante = SesionActual.EstudianteActual;
         if (estudiante == null)
         {
            // Si no hay sesión activa, mostrar un mensaje de error y devolver falso.
            MessageBox.Show("No se ha iniciado sesión como estudiante.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
         }
         return true;
      }


      /// <summary>
      ///  Método para obtener la lista de eventos y partidos asistidos por el estudiante.
      /// </summary>
      private (List<Evento> eventos, List<Partido> partidos) ObtenerDatosAsistidos()
      {
         var estudiante = SesionActual.EstudianteActual;
         // Obtener eventos asistidos usando el método correspondiente.
         var eventosAsistidos = Metodos.ObtenerEventosAsistidos(estudiante.cifEstudiante);
         // Obtener partidos asistidos usando el método correspondiente.
         var partidosAsistidos = Metodos.ObtenerPartidosAsistidos(estudiante.cifEstudiante);

         // Retornar ambas listas en forma de tupla.
         return (eventosAsistidos, partidosAsistidos);
      }

      private void CargarDatosEnListViews(List<Evento> eventos, List<Partido> partidos)
      {
         // Cargar eventos asistidos en el ListView de eventos.
         Metodos.CargarEventosAsistidos(lvwEventos, eventos);
         // Cargar partidos asistidos en el ListView de partidos.
         Metodos.CargarPartidosAsistidos(lvwPartidosAsistidos, partidos);
      }
      private void ActualizarEstadisticas()
      {
         var estudiante = SesionActual.EstudianteActual;
         // Calcular las horas laborales usando el método correspondiente.
         int horasLaborales = Metodos.CalcularHorasLaborales(estudiante.cifEstudiante);
         // Mostrar las horas laborales en la etiqueta correspondiente
         lblHorasLaborales.Text = $"Horas laborales: {horasLaborales}";
         // Calcular los beneficios en partidos completados 
         int beneficioPartidos = Metodos.CalcularBeneficioPartidos(estudiante.cifEstudiante); //Uso de metodo CalcularBeneficioPartidos para contar partidos completados de 7
         lblBeneficioPartidos.Text = $"Partidos completados: {beneficioPartidos}";// Mostrar los partidos completados en la etiqueta correspondiente.

         CrearGrafico(horasLaborales, beneficioPartidos);
      }

      private void button5_Click(object sender, EventArgs e)
      {
         UserReporte form = new UserReporte();
         form.Show();
         this.Close();
      }

      private void btnVerEventos_Click(object sender, EventArgs e)
      {
         UserEvento form = new UserEvento();
         form.Show();
         this.Close();
      }


      private void button1_Click(object sender, EventArgs e)
      {
         UserMiPerfil form = new UserMiPerfil();
         form.Show();
         this.Close();
      }

      private void btnAjustes_Click(object sender, EventArgs e)
      {
         UserCambiarContraseña form = new UserCambiarContraseña();
         form.Show();
         this.Close();
      }

      private void lblCerrarSesion_Click(object sender, EventArgs e)
      {
         IniciarSesion form = new IniciarSesion();
         form.Show();
         this.Close();
      }

      private void btnPartidos_Click(object sender, EventArgs e)
      {
         UserPartidos form = new UserPartidos();
         form.Show();
         this.Close();
      }

      private void lvEventosAsistidos_SelectedIndexChanged(object sender, EventArgs e)
      {

      }

      private void chart1_Click(object sender, EventArgs e)
      {

      }

      private void lvwEventos_SelectedIndexChanged(object sender, EventArgs e)
      {

      }

      private void label3_Click(object sender, EventArgs e)
      {

      }

      private void label2_Click(object sender, EventArgs e)
      {
         IniciarSesion form = new IniciarSesion();
         form.Show();
         this.Close();
      }

      private void pnlPieArriba_Paint(object sender, PaintEventArgs e)
      {

      }

      private void groupBox1_Enter(object sender, EventArgs e)
      {

      }

      private void gbxPartidosAsistidos_Enter(object sender, EventArgs e)
      {

      }

      private void lblHorasLaborales_Click(object sender, EventArgs e)
      {

      }


      private void CrearGrafico(int horasLaborales, int beneficioPartidos)
      {
         // Limpiar cualquier serie o título previo en el gráfico.
         chart1.Series.Clear();
         chart1.Titles.Clear();
         /// <summary>
         /// La creación de un objeto Series en C# se utiliza comúnmente 
         /// para agregar datos a un control de gráficos (Chart) en aplicaciones Windows Forms
         /// </summary>
         var series = new Series
         {
            Name = "Horas y Partidos", // nombre de la serie
            IsValueShownAsLabel = true, // Mostrar los valores como etiquetas y Determina si los valores se muestran como etiquetas en el gráfico.
            ChartType = SeriesChartType.Pie // Tipo de grafico ; pastel
         };
         // Agregar puntos a la serie con los datos de horas laborales y partidos completados.
         series.Points.AddXY("Horas Laborales", horasLaborales);
         series.Points.AddXY("Partidos completados", beneficioPartidos);
         // Configurar el formato de las etiquetas en el gráfico
         series.Label = "#VALX: #VAL (#PERCENT{P0})";
         // Agregar la serie al gráfico
         chart1.Series.Add(series);
         chart1.Titles.Add("Horas Laborales y Partidos completados");
      }

      private void lvwPartidosAsistidos_SelectedIndexChanged(object sender, EventArgs e)
      {

      }
   }
}
