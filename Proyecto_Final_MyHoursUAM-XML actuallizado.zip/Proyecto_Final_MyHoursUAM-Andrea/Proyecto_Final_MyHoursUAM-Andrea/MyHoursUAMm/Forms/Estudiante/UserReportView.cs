﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyHours_UAMApp.Estructuras.Metodos;
using MyHours_UAMApp.Estructuras;
using Microsoft.Reporting.WinForms;
using System.IO;
using System;
using System.Security.Cryptography;

namespace MyHours_UAMApp.Forms.Estudiante
{
    public partial class UserReportView : Form
    {
        public UserReportView()
        {
            InitializeComponent();
        }

        private void gpbDatosPersonales_Enter(object sender, EventArgs e)
        {

        }

        private void pnlPieArriba_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnlAreaAdministrador_Paint(object sender, PaintEventArgs e)
        {

        }

        private void UserReportView_Load(object sender, EventArgs e)
        {
            var estudiante = SesionActual.EstudianteActual; // var + nombre + = + nombre clase + parametro

            if (estudiante == null)
            {
                MessageBox.Show("No se ha iniciado sesión como estudiante.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close(); // Cierra el formulario si no hay sesión
                return;
            }

            // Obtener eventos asistidos por el estudiante
            var eventosAsistidos = Metodos.ObtenerEventosAsistidos(estudiante.cifEstudiante);

            // Configurar el ReportViewer       clase + funcion + parametros
            Metodos.ConfigurarReportViewer(reportViewer1, eventosAsistidos);

            this.reportViewer1.RefreshReport(); // refrescar reporte
        }

        private void lblEstudiante_Click(object sender, EventArgs e)
        {
            UserMiPerfil form = new UserMiPerfil();
            form.Show();
            this.Close();
        }

        private void lblCerrarSesion_Click(object sender, EventArgs e)
        {
            IniciarSesion form = new IniciarSesion();
            form.Show();
            this.Close();
        }

        private void btnVerEventos_Click(object sender, EventArgs e)
        {
            UserEvento form = new UserEvento();
            form.Show();
            this.Close();
        }

        private void btnPartidos_Click(object sender, EventArgs e)
        {
            UserPartidos form = new UserPartidos();
            form.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserMiPerfil form = new UserMiPerfil();
            form.Show();
            this.Close();
        }

        private void btnAjustes_Click(object sender, EventArgs e)
        {
            UserCambiarContraseña form = new UserCambiarContraseña();
            form.Show();
            this.Close();
        }

        private void btnReporte_Click(object sender, EventArgs e)
        {
            UserReporte form = new UserReporte();
            form.Show();
            this.Close();
        }

        /// <summary>
        /// Métodos para exportar reporte
        /// </summary>
        
        private void ExportarReporte(string formato, string nombreArchivo)
        {
            Warning[] warnings; // arreglo q almacena advertencias 
            string[] streamIds; //Arreglo de identificadores de flujos de datos o partes de un archivo.
            string mimeType; // tipod de archivo 
            string encoding; //Tipo de codificación del texto o datos
            string extension; //Extensión del archivo en el que se exporta el reporte

            // Renderizar el reporte en el formato deseado
            byte[] bytes = reportViewer1.LocalReport.Render(
                formato, null, out mimeType, out encoding, out extension, out streamIds, out warnings);

         ///<summary
         // Guardar el archivo exportado
         //Construye la ruta completa del archivo combinando
         // El escritorio del usuario(Environment.SpecialFolder.Desktop).
         // El nombre del archivo(nombreArchivo) y su extensión(extension).
         /// </summary>


         string rutaArchivo = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), nombreArchivo + "." + extension);
            File.WriteAllBytes(rutaArchivo, bytes); //Guarda el contenido binario(bytes)

            // Mostrar mensaje de éxito
            MessageBox.Show($"Reporte exportado como {formato.ToUpper()} en:\n{rutaArchivo}", "Exportación Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnExportarPDF_Click(object sender, EventArgs e)
        {
            ExportarReporte("PDF", "Reporte"); // formato en el que se exporta el reporte
        }

        private void btnExportarExcel_Click(object sender, EventArgs e)
        {
            ExportarReporte("EXCEL", "Reporte"); // formato en el que se exporta el reporte
      
        }

        private void btnExportarWord_Click(object sender, EventArgs e)
        {
            ExportarReporte("WORD", "Reporte"); // formato en el que se exporta el reporte
      
        }

      private void reportViewer1_Load(object sender, EventArgs e)
      {

      }
   }
}

