﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyHours_UAMApp.Estructuras;

namespace MyHours_UAMApp.ServicioEstudiante
{
   internal class EstudianteArchivoServicio
   {
      public void GuardarEstudiantes(List<Estudiante> estudiantes, string rutaArchivo)
      {

         using (FileStream archivo = new FileStream(rutaArchivo, FileMode.Create, FileAccess.Write))
         {
            using (BinaryWriter escritor = new BinaryWriter(archivo))
            {
               foreach (Estudiante c in estudiantes)
               {
                  escritor.Write(c.cifEstudiante);
                  escritor.Write(c.nombreEstudiante.Length);
                  escritor.Write(c.nombreEstudiante.ToCharArray());
                  escritor.Write(c.correoEstudiante.Length);
                  escritor.Write(c.correoEstudiante.ToCharArray());
                  escritor.Write(c.contraseñaEstudiante.Length);
                  escritor.Write(c.contraseñaEstudiante.ToCharArray());
                  escritor.Write(c.eventosAsistidos.Length);
                  escritor.Write(c.eventosAsistidos.ToCharArray());
                  escritor.Write(c.partidosAsistidos.Length);
                  escritor.Write(c.partidosAsistidos.ToCharArray());
                  escritor.Write(c.horasCompletadas);
                  escritor.Write(c.cantidadPartidosAsistidos);
                  escritor.Write(c.comprobanteAsistencia.Length);
                  escritor.Write(c.comprobanteAsistencia.ToCharArray());
                  escritor.Write(c.solicitudAsistencia.Length);
                  escritor.Write(c.solicitudAsistencia.ToCharArray());
               }
            }
         }


      }

      public List<Estudiante> CargarEstudiantes(string rutaArchivo)
      {
         List<Estudiante> estudiantes = new List<Estudiante>();

         // Verificar si el archivo existe
         if (!File.Exists(rutaArchivo))
         {
            return estudiantes;
         }

         using (FileStream archivo = new FileStream(rutaArchivo, FileMode.Open, FileAccess.Read))
         {
            using (BinaryReader lector = new BinaryReader(archivo))
            {
               // Leer mientras no lleguemos al final del archivo
               while (archivo.Position != archivo.Length)
               {
                  // Leer las propiedades del estudiante en el mismo orden en que se guardaron
                  int tamañocifEstudiante = lector.ReadInt32();
                  char[] cifArray = lector.ReadChars(tamañocifEstudiante);
                  string cifEstudiante = new string(cifArray);


                  int tamañoNombre = lector.ReadInt32();
                  char[] nombreArray = lector.ReadChars(tamañoNombre);
                  string nombreEstudiante = new string(nombreArray);

                  int tamañoCorreo = lector.ReadInt32();
                  char[] correoArray = lector.ReadChars(tamañoCorreo);
                  string correoEstudiante = new string(correoArray);

                  int tamañoContraseña = lector.ReadInt32();
                  char[] contraseñaArray = lector.ReadChars(tamañoContraseña);
                  string contraseñaEstudiante = new string(contraseñaArray);

                  int tamañoEventos = lector.ReadInt32();
                  char[] eventosArray = lector.ReadChars(tamañoEventos);
                  string eventosAsistidos = new string(eventosArray);

                  int tamañoPartidos = lector.ReadInt32();
                  char[] partidosArray = lector.ReadChars(tamañoPartidos);
                  string partidosAsistidos = new string(partidosArray);

                  int horasCompletadas = lector.ReadInt32();
                  int cantidadPartidosAsistidos = lector.ReadInt32();

                  int tamañoComprobante = lector.ReadInt32();
                  char[] comprobanteArray = lector.ReadChars(tamañoComprobante);
                  string comprobanteAsistencia = new string(comprobanteArray);

                  int tamañoSolicitud = lector.ReadInt32();
                  char[] solicitudArray = lector.ReadChars(tamañoSolicitud);
                  string solicitudAsistencia = new string(solicitudArray);


               }
            }

            return estudiantes;
         }




      }
   }
}
