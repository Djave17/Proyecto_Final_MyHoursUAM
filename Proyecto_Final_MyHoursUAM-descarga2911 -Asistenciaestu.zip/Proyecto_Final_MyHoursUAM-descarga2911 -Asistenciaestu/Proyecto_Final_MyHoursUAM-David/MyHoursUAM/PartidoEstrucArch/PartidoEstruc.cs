﻿using MyHours_UAMApp.Estructuras;
using System;
using System.Collections.Generic;
using System.IO;
using static MyHours_UAMApp.Estructuras.Evento;
using static MyHours_UAMApp.Estructuras.Partido;

namespace MyHours_UAMApp.ServicioPartidoArch
{
   internal class PartidoArchivoServicio
   {
      public void GuardarPartidos(List<Partido> partidos, string rutaArchivo3)
      {
         using (FileStream archivo = new FileStream(rutaArchivo3, FileMode.Create, FileAccess.Write))
         {
            using (BinaryWriter escritor = new BinaryWriter(archivo))
            {
               foreach (Partido c in partidos)
               {
                  // Guardar propiedades específicas de Partido
                  escritor.Write(c.nombrePartido.Length);
                  escritor.Write(c.nombrePartido.ToCharArray());
                  escritor.Write(c.lugarPartido.Length);
                  escritor.Write(c.lugarPartido.ToCharArray());
                  escritor.Write(c.rival.Length);
                  escritor.Write(c.rival.ToCharArray());
                  escritor.Write((int)c.deporte); // Guardar el enum TipoDeporte como entero

                  // Guardar propiedades heredadas de Evento
                  escritor.Write(c.nombreEvento.Length);
                  escritor.Write(c.nombreEvento.ToCharArray());
                  escritor.Write(c.fechaEvento.Length);
                  escritor.Write(c.fechaEvento.ToCharArray());
                  escritor.Write(c.horaEvento.Length);
                  escritor.Write(c.horaEvento.ToCharArray());
                  escritor.Write(c.descripcionEvento.Length);
                  escritor.Write(c.descripcionEvento.ToCharArray());
                  escritor.Write(c.cantidadConvalidar);
                  escritor.Write(c.organizadorEvento.Length);
                  escritor.Write(c.organizadorEvento.ToCharArray());
                  escritor.Write(c.lugarEvento.Length);
                  escritor.Write(c.lugarEvento.ToCharArray());
                  escritor.Write(c.idEvento.Length);
                  escritor.Write(c.idEvento.ToCharArray());
                  escritor.Write(c.cupos);
                  escritor.Write((int)c.estadoEvento); // Guardar EstadoEvento como entero
                  escritor.Write((int)c.tipoEvento);   // Guardar TipoEvento como entero
               }
            }
         }
      }

      public List<Partido> CargarPartidos(string rutaArchivo3)
      {
         List<Partido> partidos = new List<Partido>();

         if (!File.Exists(rutaArchivo3))
         {
            return partidos;
         }

         using (FileStream archivo = new FileStream(rutaArchivo3, FileMode.Open, FileAccess.Read))
         {
            using (BinaryReader lector = new BinaryReader(archivo))
            {
               while (archivo.Position < archivo.Length)
               {
                  // Leer propiedades específicas de Partido
                  int tamNombrePartido = lector.ReadInt32();
                  string nombrePartido = new string(lector.ReadChars(tamNombrePartido));

                  int tamLugarPartido = lector.ReadInt32();
                  string lugarPartido = new string(lector.ReadChars(tamLugarPartido));

                  int tamRival = lector.ReadInt32();
                  string rival = new string(lector.ReadChars(tamRival));

                  TipoDeporte deporte = (TipoDeporte)lector.ReadInt32(); // Leer el enum como entero

                  // Leer propiedades heredadas de Evento
                  int tamNombreEvento = lector.ReadInt32();
                  string nombreEvento = new string(lector.ReadChars(tamNombreEvento));

                  int tamFechaEvento = lector.ReadInt32();
                  string fechaEvento = new string(lector.ReadChars(tamFechaEvento));

                  int tamHoraEvento = lector.ReadInt32();
                  string horaEvento = new string(lector.ReadChars(tamHoraEvento));

                  int tamDescripcionEvento = lector.ReadInt32();
                  string descripcionEvento = new string(lector.ReadChars(tamDescripcionEvento));

                  int cantidadConvalidar = lector.ReadInt32();

                  int tamOrganizadorEvento = lector.ReadInt32();
                  string organizadorEvento = new string(lector.ReadChars(tamOrganizadorEvento));

                  int tamLugarEvento = lector.ReadInt32();
                  string lugarEvento = new string(lector.ReadChars(tamLugarEvento));

                  int tamIdEvento = lector.ReadInt32();
                  string idEvento = new string(lector.ReadChars(tamIdEvento));

                  int cupos = lector.ReadInt32();

                  EstadoEvento estado = (EstadoEvento)lector.ReadInt32(); // Leer EstadoEvento como entero
                  TipoEvento tipo = (TipoEvento)lector.ReadInt32();      // Leer TipoEvento como entero




               }
            }
         }

         return partidos;
      }
   }
}
