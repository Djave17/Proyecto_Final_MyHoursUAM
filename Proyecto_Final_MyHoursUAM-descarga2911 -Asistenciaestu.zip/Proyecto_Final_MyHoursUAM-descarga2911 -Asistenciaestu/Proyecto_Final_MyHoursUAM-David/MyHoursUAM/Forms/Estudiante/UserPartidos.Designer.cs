﻿namespace MyHours_UAMApp
{
    partial class UserPartidos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserPartidos));
         this.pnlPieArriba = new System.Windows.Forms.Panel();
         this.lblCerrarSesion = new System.Windows.Forms.Label();
         this.pcbLogOutIcon = new System.Windows.Forms.PictureBox();
         this.lblEstudiante = new System.Windows.Forms.Label();
         this.pcbStudentIcon = new System.Windows.Forms.PictureBox();
         this.label1 = new System.Windows.Forms.Label();
         this.pnlAreaAdministrador = new System.Windows.Forms.Panel();
         this.panel1 = new System.Windows.Forms.Panel();
         this.btnPartidos = new System.Windows.Forms.Button();
         this.btnReporte = new System.Windows.Forms.Button();
         this.button1 = new System.Windows.Forms.Button();
         this.panel2 = new System.Windows.Forms.Panel();
         this.btnAjustes = new System.Windows.Forms.Button();
         this.btnVerEventos = new System.Windows.Forms.Button();
         this.pnlIcon = new System.Windows.Forms.Panel();
         this.pictureBox1 = new System.Windows.Forms.PictureBox();
         this.listView1 = new System.Windows.Forms.ListView();
         this.gbxEstudianteEventos = new System.Windows.Forms.GroupBox();
         this.label3 = new System.Windows.Forms.Label();
         this.label2 = new System.Windows.Forms.Label();
         this.button2 = new System.Windows.Forms.Button();
         this.lvPartidos = new System.Windows.Forms.ListView();
         this.clhNombrePartido = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
         this.clhLugarPartido = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
         this.clhDeporte = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
         this.clhHora = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
         this.clhFecha = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
         this.clhHoraEnvio = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
         this.clhCantidadConvalidar = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
         this.clhCupos = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
         this.pnlPieArriba.SuspendLayout();
         ((System.ComponentModel.ISupportInitialize)(this.pcbLogOutIcon)).BeginInit();
         ((System.ComponentModel.ISupportInitialize)(this.pcbStudentIcon)).BeginInit();
         this.pnlAreaAdministrador.SuspendLayout();
         this.panel1.SuspendLayout();
         this.pnlIcon.SuspendLayout();
         ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
         this.gbxEstudianteEventos.SuspendLayout();
         this.SuspendLayout();
         // 
         // pnlPieArriba
         // 
         this.pnlPieArriba.BackColor = System.Drawing.Color.White;
         this.pnlPieArriba.Controls.Add(this.lblCerrarSesion);
         this.pnlPieArriba.Controls.Add(this.pcbLogOutIcon);
         this.pnlPieArriba.Controls.Add(this.lblEstudiante);
         this.pnlPieArriba.Controls.Add(this.pcbStudentIcon);
         this.pnlPieArriba.Controls.Add(this.label1);
         this.pnlPieArriba.Dock = System.Windows.Forms.DockStyle.Top;
         this.pnlPieArriba.Location = new System.Drawing.Point(220, 0);
         this.pnlPieArriba.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.pnlPieArriba.Name = "pnlPieArriba";
         this.pnlPieArriba.Size = new System.Drawing.Size(945, 90);
         this.pnlPieArriba.TabIndex = 9;
         // 
         // lblCerrarSesion
         // 
         this.lblCerrarSesion.AutoSize = true;
         this.lblCerrarSesion.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.lblCerrarSesion.ForeColor = System.Drawing.Color.Teal;
         this.lblCerrarSesion.Location = new System.Drawing.Point(820, 43);
         this.lblCerrarSesion.Name = "lblCerrarSesion";
         this.lblCerrarSesion.Size = new System.Drawing.Size(102, 16);
         this.lblCerrarSesion.TabIndex = 8;
         this.lblCerrarSesion.Text = "Cerrar Sesion";
         this.lblCerrarSesion.Click += new System.EventHandler(this.lblCerrarSesion_Click);
         // 
         // pcbLogOutIcon
         // 
         this.pcbLogOutIcon.Image = ((System.Drawing.Image)(resources.GetObject("pcbLogOutIcon.Image")));
         this.pcbLogOutIcon.Location = new System.Drawing.Point(761, 23);
         this.pcbLogOutIcon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.pcbLogOutIcon.Name = "pcbLogOutIcon";
         this.pcbLogOutIcon.Size = new System.Drawing.Size(53, 50);
         this.pcbLogOutIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
         this.pcbLogOutIcon.TabIndex = 7;
         this.pcbLogOutIcon.TabStop = false;
         // 
         // lblEstudiante
         // 
         this.lblEstudiante.AutoSize = true;
         this.lblEstudiante.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.lblEstudiante.ForeColor = System.Drawing.Color.Teal;
         this.lblEstudiante.Location = new System.Drawing.Point(673, 43);
         this.lblEstudiante.Name = "lblEstudiante";
         this.lblEstudiante.Size = new System.Drawing.Size(80, 16);
         this.lblEstudiante.TabIndex = 5;
         this.lblEstudiante.Text = "Estudiante";
         // 
         // pcbStudentIcon
         // 
         this.pcbStudentIcon.Image = ((System.Drawing.Image)(resources.GetObject("pcbStudentIcon.Image")));
         this.pcbStudentIcon.Location = new System.Drawing.Point(620, 26);
         this.pcbStudentIcon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.pcbStudentIcon.Name = "pcbStudentIcon";
         this.pcbStudentIcon.Size = new System.Drawing.Size(48, 47);
         this.pcbStudentIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
         this.pcbStudentIcon.TabIndex = 6;
         this.pcbStudentIcon.TabStop = false;
         // 
         // label1
         // 
         this.label1.AutoSize = true;
         this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label1.ForeColor = System.Drawing.Color.Teal;
         this.label1.Location = new System.Drawing.Point(27, 26);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(236, 38);
         this.label1.TabIndex = 2;
         this.label1.Text = "DASHBOARD";
         // 
         // pnlAreaAdministrador
         // 
         this.pnlAreaAdministrador.BackColor = System.Drawing.Color.Teal;
         this.pnlAreaAdministrador.Controls.Add(this.panel1);
         this.pnlAreaAdministrador.Controls.Add(this.pnlIcon);
         this.pnlAreaAdministrador.Dock = System.Windows.Forms.DockStyle.Left;
         this.pnlAreaAdministrador.ForeColor = System.Drawing.Color.White;
         this.pnlAreaAdministrador.Location = new System.Drawing.Point(0, 0);
         this.pnlAreaAdministrador.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.pnlAreaAdministrador.Name = "pnlAreaAdministrador";
         this.pnlAreaAdministrador.Size = new System.Drawing.Size(220, 774);
         this.pnlAreaAdministrador.TabIndex = 8;
         // 
         // panel1
         // 
         this.panel1.Controls.Add(this.btnPartidos);
         this.panel1.Controls.Add(this.btnReporte);
         this.panel1.Controls.Add(this.button1);
         this.panel1.Controls.Add(this.panel2);
         this.panel1.Controls.Add(this.btnAjustes);
         this.panel1.Controls.Add(this.btnVerEventos);
         this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
         this.panel1.Location = new System.Drawing.Point(0, 90);
         this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.panel1.Name = "panel1";
         this.panel1.Size = new System.Drawing.Size(220, 763);
         this.panel1.TabIndex = 2;
         // 
         // btnPartidos
         // 
         this.btnPartidos.BackColor = System.Drawing.Color.Transparent;
         this.btnPartidos.Cursor = System.Windows.Forms.Cursors.Hand;
         this.btnPartidos.FlatAppearance.BorderSize = 0;
         this.btnPartidos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnPartidos.Font = new System.Drawing.Font("MS UI Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.btnPartidos.ForeColor = System.Drawing.Color.White;
         this.btnPartidos.Location = new System.Drawing.Point(3, 130);
         this.btnPartidos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.btnPartidos.Name = "btnPartidos";
         this.btnPartidos.Size = new System.Drawing.Size(211, 119);
         this.btnPartidos.TabIndex = 16;
         this.btnPartidos.Text = "⚽ Partidos";
         this.btnPartidos.UseVisualStyleBackColor = false;
         this.btnPartidos.Click += new System.EventHandler(this.btnPartidos_Click);
         // 
         // btnReporte
         // 
         this.btnReporte.BackColor = System.Drawing.Color.Transparent;
         this.btnReporte.Cursor = System.Windows.Forms.Cursors.Hand;
         this.btnReporte.FlatAppearance.BorderSize = 0;
         this.btnReporte.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnReporte.Font = new System.Drawing.Font("MS UI Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.btnReporte.ForeColor = System.Drawing.Color.White;
         this.btnReporte.Location = new System.Drawing.Point(-3, 512);
         this.btnReporte.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.btnReporte.Name = "btnReporte";
         this.btnReporte.Size = new System.Drawing.Size(220, 119);
         this.btnReporte.TabIndex = 15;
         this.btnReporte.Text = "📄 Reporte";
         this.btnReporte.UseVisualStyleBackColor = false;
         this.btnReporte.Click += new System.EventHandler(this.btnReporte_Click);
         // 
         // button1
         // 
         this.button1.BackColor = System.Drawing.Color.Transparent;
         this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
         this.button1.FlatAppearance.BorderSize = 0;
         this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.button1.Font = new System.Drawing.Font("MS UI Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.button1.ForeColor = System.Drawing.Color.White;
         this.button1.Location = new System.Drawing.Point(9, 250);
         this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.button1.Name = "button1";
         this.button1.Size = new System.Drawing.Size(208, 122);
         this.button1.TabIndex = 13;
         this.button1.Text = "👤 Mi Perfil";
         this.button1.UseVisualStyleBackColor = false;
         this.button1.Click += new System.EventHandler(this.button1_Click);
         // 
         // panel2
         // 
         this.panel2.BackColor = System.Drawing.Color.White;
         this.panel2.Location = new System.Drawing.Point(0, 124);
         this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.panel2.Name = "panel2";
         this.panel2.Size = new System.Drawing.Size(5, 127);
         this.panel2.TabIndex = 3;
         // 
         // btnAjustes
         // 
         this.btnAjustes.BackColor = System.Drawing.Color.Transparent;
         this.btnAjustes.Cursor = System.Windows.Forms.Cursors.Hand;
         this.btnAjustes.FlatAppearance.BorderSize = 0;
         this.btnAjustes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnAjustes.Font = new System.Drawing.Font("MS UI Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.btnAjustes.ForeColor = System.Drawing.Color.White;
         this.btnAjustes.Location = new System.Drawing.Point(-3, 378);
         this.btnAjustes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.btnAjustes.Name = "btnAjustes";
         this.btnAjustes.Size = new System.Drawing.Size(220, 122);
         this.btnAjustes.TabIndex = 12;
         this.btnAjustes.Text = "⚙️   Ajustes";
         this.btnAjustes.UseVisualStyleBackColor = false;
         this.btnAjustes.Click += new System.EventHandler(this.btnAjustes_Click);
         // 
         // btnVerEventos
         // 
         this.btnVerEventos.BackColor = System.Drawing.Color.Transparent;
         this.btnVerEventos.Cursor = System.Windows.Forms.Cursors.Hand;
         this.btnVerEventos.FlatAppearance.BorderSize = 0;
         this.btnVerEventos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.btnVerEventos.Font = new System.Drawing.Font("MS UI Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.btnVerEventos.ForeColor = System.Drawing.Color.White;
         this.btnVerEventos.Location = new System.Drawing.Point(-3, 6);
         this.btnVerEventos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.btnVerEventos.Name = "btnVerEventos";
         this.btnVerEventos.Size = new System.Drawing.Size(220, 122);
         this.btnVerEventos.TabIndex = 10;
         this.btnVerEventos.Text = "👁  Ver Eventos";
         this.btnVerEventos.UseVisualStyleBackColor = false;
         this.btnVerEventos.Click += new System.EventHandler(this.btnVerEventos_Click);
         // 
         // pnlIcon
         // 
         this.pnlIcon.Controls.Add(this.pictureBox1);
         this.pnlIcon.Dock = System.Windows.Forms.DockStyle.Top;
         this.pnlIcon.Location = new System.Drawing.Point(0, 0);
         this.pnlIcon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.pnlIcon.Name = "pnlIcon";
         this.pnlIcon.Size = new System.Drawing.Size(220, 90);
         this.pnlIcon.TabIndex = 1;
         // 
         // pictureBox1
         // 
         this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
         this.pictureBox1.Location = new System.Drawing.Point(81, 6);
         this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.pictureBox1.Name = "pictureBox1";
         this.pictureBox1.Size = new System.Drawing.Size(52, 78);
         this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
         this.pictureBox1.TabIndex = 0;
         this.pictureBox1.TabStop = false;
         this.pictureBox1.WaitOnLoad = true;
         // 
         // listView1
         // 
         this.listView1.HideSelection = false;
         this.listView1.Location = new System.Drawing.Point(227, 96);
         this.listView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.listView1.Name = "listView1";
         this.listView1.Size = new System.Drawing.Size(923, 665);
         this.listView1.TabIndex = 10;
         this.listView1.UseCompatibleStateImageBehavior = false;
         // 
         // gbxEstudianteEventos
         // 
         this.gbxEstudianteEventos.Controls.Add(this.label3);
         this.gbxEstudianteEventos.Controls.Add(this.label2);
         this.gbxEstudianteEventos.Controls.Add(this.button2);
         this.gbxEstudianteEventos.Controls.Add(this.lvPartidos);
         this.gbxEstudianteEventos.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.gbxEstudianteEventos.Location = new System.Drawing.Point(255, 113);
         this.gbxEstudianteEventos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
         this.gbxEstudianteEventos.Name = "gbxEstudianteEventos";
         this.gbxEstudianteEventos.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
         this.gbxEstudianteEventos.Size = new System.Drawing.Size(867, 623);
         this.gbxEstudianteEventos.TabIndex = 11;
         this.gbxEstudianteEventos.TabStop = false;
         this.gbxEstudianteEventos.Text = "Eventos";
         // 
         // label3
         // 
         this.label3.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label3.Location = new System.Drawing.Point(8, 86);
         this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(859, 53);
         this.label3.TabIndex = 92;
         this.label3.Text = "Es necesario enviar un comprobante de asistencia. ";
         // 
         // label2
         // 
         this.label2.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label2.Location = new System.Drawing.Point(8, 33);
         this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(859, 53);
         this.label2.TabIndex = 91;
         this.label2.Text = "Marcar asistencia seleccione el evento que esté disponible según la hora de envío" +
    " de la asistencia.";
         this.label2.Click += new System.EventHandler(this.label2_Click);
         // 
         // button2
         // 
         this.button2.BackColor = System.Drawing.Color.CadetBlue;
         this.button2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
         this.button2.Location = new System.Drawing.Point(8, 148);
         this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
         this.button2.Name = "button2";
         this.button2.Size = new System.Drawing.Size(235, 36);
         this.button2.TabIndex = 90;
         this.button2.Text = "Enviar asistencia ";
         this.button2.UseVisualStyleBackColor = false;
         this.button2.Click += new System.EventHandler(this.button2_Click);
         // 
         // lvPartidos
         // 
         this.lvPartidos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clhNombrePartido,
            this.clhLugarPartido,
            this.clhDeporte,
            this.clhHora,
            this.clhFecha,
            this.clhHoraEnvio,
            this.clhCantidadConvalidar,
            this.clhCupos});
         this.lvPartidos.FullRowSelect = true;
         this.lvPartidos.HideSelection = false;
         this.lvPartidos.Location = new System.Drawing.Point(0, 193);
         this.lvPartidos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.lvPartidos.Name = "lvPartidos";
         this.lvPartidos.Size = new System.Drawing.Size(865, 429);
         this.lvPartidos.TabIndex = 89;
         this.lvPartidos.UseCompatibleStateImageBehavior = false;
         this.lvPartidos.View = System.Windows.Forms.View.Details;
         // 
         // clhNombrePartido
         // 
         this.clhNombrePartido.Text = "Nombre";
         this.clhNombrePartido.Width = 120;
         // 
         // clhLugarPartido
         // 
         this.clhLugarPartido.Text = "Lugar";
         this.clhLugarPartido.Width = 120;
         // 
         // clhDeporte
         // 
         this.clhDeporte.Text = "Deporte";
         this.clhDeporte.Width = 90;
         // 
         // clhHora
         // 
         this.clhHora.Text = "Hora";
         // 
         // clhFecha
         // 
         this.clhFecha.Text = "Fecha";
         this.clhFecha.Width = 100;
         // 
         // clhHoraEnvio
         // 
         this.clhHoraEnvio.Text = "Hora de envio";
         this.clhHoraEnvio.Width = 200;
         // 
         // clhCantidadConvalidar
         // 
         this.clhCantidadConvalidar.Text = "Cantidad a convalidar";
         // 
         // clhCupos
         // 
         this.clhCupos.Text = "Cupos";
         this.clhCupos.Width = 75;
         // 
         // UserPartidos
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(1165, 774);
         this.Controls.Add(this.gbxEstudianteEventos);
         this.Controls.Add(this.listView1);
         this.Controls.Add(this.pnlPieArriba);
         this.Controls.Add(this.pnlAreaAdministrador);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
         this.Name = "UserPartidos";
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
         this.Text = "MyHoursUAM - Partidos";
         this.pnlPieArriba.ResumeLayout(false);
         this.pnlPieArriba.PerformLayout();
         ((System.ComponentModel.ISupportInitialize)(this.pcbLogOutIcon)).EndInit();
         ((System.ComponentModel.ISupportInitialize)(this.pcbStudentIcon)).EndInit();
         this.pnlAreaAdministrador.ResumeLayout(false);
         this.panel1.ResumeLayout(false);
         this.pnlIcon.ResumeLayout(false);
         ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
         this.gbxEstudianteEventos.ResumeLayout(false);
         this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlPieArriba;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlAreaAdministrador;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnAjustes;
        private System.Windows.Forms.Button btnVerEventos;
        private System.Windows.Forms.Panel pnlIcon;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblCerrarSesion;
        private System.Windows.Forms.PictureBox pcbLogOutIcon;
        private System.Windows.Forms.Label lblEstudiante;
        private System.Windows.Forms.PictureBox pcbStudentIcon;
        private System.Windows.Forms.Button btnReporte;
        private System.Windows.Forms.Button btnPartidos;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.GroupBox gbxEstudianteEventos;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView lvPartidos;
        private System.Windows.Forms.ColumnHeader clhNombrePartido;
        private System.Windows.Forms.ColumnHeader clhLugarPartido;
        private System.Windows.Forms.ColumnHeader clhDeporte;
        private System.Windows.Forms.ColumnHeader clhHora;
        private System.Windows.Forms.ColumnHeader clhFecha;
        private System.Windows.Forms.ColumnHeader clhHoraEnvio;
        private System.Windows.Forms.ColumnHeader clhCantidadConvalidar;
        private System.Windows.Forms.ColumnHeader clhCupos;
    }
}