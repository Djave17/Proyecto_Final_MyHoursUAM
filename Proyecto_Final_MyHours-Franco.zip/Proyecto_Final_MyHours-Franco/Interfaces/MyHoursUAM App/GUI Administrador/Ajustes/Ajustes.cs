﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyHoursUAM_App.GUI_Administrador.Ajustes
{
    public partial class Ajustes : Form
    {
        public Ajustes()
        {
            InitializeComponent();
        }
    }
}
