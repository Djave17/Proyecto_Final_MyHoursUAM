﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyHoursUAM_App.GUI_Administrador.Asistencia.Lista_de_Asistencia
{
    public partial class Lista_Asistencia : Form
    {
        public Lista_Asistencia()
        {
            InitializeComponent();
        }
    }
}
