﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyHours_UAMApp.Estructuras
{
    [Serializable]
    internal class SolicitudAsistencia
    {

      /// <summary>
      /// Representa una solicitud de asistencia a un evento o partido por parte de un estudiante.
      /// </summary>
      public string Id { get; set; }
        public string EstudianteId { get; set; }
        public string EventoId { get; set; }
        public Evento Eventos { get; set; } //Detalles del evento al que se asiste, si aplica.
      public Partido Partidos { get; set; } //Detalles del partido al que se asiste, si aplica.
      public enum Estado // enum para los distintos estados de las actividades
        {
            Pendiente,
            Aprobado,
            Rechazado
        }// Pendiente, Aprobado, Rechazado
        public Estado EstadoSolicitud { get; set; }  //Estado actual de la solicitud.
      public DateTime FechaSolicitud { get; set; }
        
    }
}
