﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyHours_UAMApp.Estructuras
{
    [Serializable]
    internal class Evento
    {
      /// <summary>
      /// Representa un evento disponible para los estudiantes, con sus detalles principales.
      /// </summary>
      public string nombreEvento { get; set; }
        public enum EstadoEvento // Enum que define el estado del evento (disponible o no disponible).
      {
            Disponible,
            No_Disponible
        }

        public EstadoEvento estadoEvento { get; set; }
        public string fechaEvento { get; set; }
        public string horaEvento { get; set; }
        public string descripcionEvento { get; set; }
        public int cantidadConvalidar { get; set; }
        public string organizadorEvento { get; set; }
        public string lugarEvento { get; set; }
        public string tipoBeneficio { get; set; }
        public string idEvento { get; set; }
        public int cupos { get; set; }

        public enum TipoEvento //Enum que define el tipo de evento (deportivo, cultural, etc.).
      {
            deportivo,
            cultural,
            social,
            voluntario
        }
        public TipoEvento tipoEvento { get; set; }
    }
}
