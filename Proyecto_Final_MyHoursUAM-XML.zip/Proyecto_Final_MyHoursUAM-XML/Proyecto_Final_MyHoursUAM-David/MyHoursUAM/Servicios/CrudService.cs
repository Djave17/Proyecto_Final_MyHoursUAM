﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MyHours_UAMApp
{
    public class CrudService<T>
    {


      /// <summary>
      /// Servicio genérico para realizar operaciones CRUD (Crear, Leer, Actualizar, Eliminar) sobre datos almacenados en un archivo binario.
      /// </summary>

      private readonly string filePath;
        public List<T> Data { get; private set; } //El tipo de objeto que se almacenará en la lista y en el archivo

      public CrudService(string filePath)
      {
            this.filePath = filePath; //Filepath ruta del archivo binario donde se guardarán los datos.                                 
         Data = LoadData();
      }


      /// <summary>
      /// Carga los datos desde el archivo binario.
      /// </summary>
      private List<T> LoadData() //Lista que contiene los datos cargados desde el archivo.
      {
            if (File.Exists(filePath))
            {
                using (FileStream stream = File.Open(filePath, FileMode.Open))
                {
                  //Crea un formateador binario para deserializar los datos.
                   BinaryFormatter formatter = new BinaryFormatter();
               // Deserializa los datos y los devuelve como una lista ( Convertir los datos guardados en el archivo de nuevo en el objeto original.)
               return (List<T>)formatter.Deserialize(stream);

                 

                }
            }
            return new List<T>();  //Si el archivo no existe, devuelve una lista vacía.
      }
     
        public void SaveData()
        {
         // Abre o crea el archivo en modo escritura.
            using (FileStream stream = File.Create(filePath))
            {
            // Crea un formateador binario para serializar los datos.
            BinaryFormatter formatter = new BinaryFormatter();
            // Serializa la lista de datos y los guarda en el archivo.
            formatter.Serialize(stream, Data);


               /// <summary>
               /// Serializar es convertir los datos de un objeto en una forma que pueda guardarse en un archivo.
               ///BinaryFormatter es la herramienta que hace esa conversión a un formato binario.
               /// Serialize es el proceso de guardar esa versión "empaquetada" del objeto en el archivo.
               /// </summary>

             }
       }

        public void Add(T item)
        {
         // Agrega el elemento a la lista en memoria.
         Data.Add(item);
         // Guarda la lista actualizada en el archivo.
         SaveData();
        }



      /// <summary>
      /// Actualiza un elemento existente en la lista si coincide con un criterio.
      /// </summary>
      public void Update(Predicate<T> match, T updatedItem)
        {
         // Busca el índice del elemento que cumple con el criterio.
         int index = Data.FindIndex(match);
         // Si se encuentra un elemento, lo reemplaza por el elemento actualizado.
         if (index != -1)
            {
                Data[index] = updatedItem;
                SaveData();
            }
        }

        public void Delete(Predicate<T> match)
        {
            Data.RemoveAll(match); //// Elimina todos los elementos que cumplen con el criterio.
            SaveData();
        }


      /// <summary>
      /// Obtiene todos los elementos almacenados en la lista.
      /// </summary>
      public List<T> GetAll()
        {
         // Devuelve la lista de datos en memoria.
         return Data;
        }
    }
}
